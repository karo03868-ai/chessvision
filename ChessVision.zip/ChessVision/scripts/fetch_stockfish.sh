#!/usr/bin/env bash
# Скачивает официальный Stockfish для Android (arm64) и кладёт как libstockfish.so
set -e
cd "$(dirname "$0")/.."
TAG="${1:-sf_17}"
URL="https://github.com/official-stockfish/Stockfish/releases/download/$TAG/stockfish-android-armv8.tar"
TMP="$(mktemp -d)"
curl -L "$URL" -o "$TMP/sf.tar"
tar -xf "$TMP/sf.tar" -C "$TMP"
BIN="$(find "$TMP" -type f -name 'stockfish-android-armv8*' ! -name '*.tar' | head -n1)"
[ -n "$BIN" ] || { echo "Бинарник не найден в архиве"; exit 1; }
mkdir -p app/src/main/jniLibs/arm64-v8a
cp "$BIN" app/src/main/jniLibs/arm64-v8a/libstockfish.so
echo "Готово: app/src/main/jniLibs/arm64-v8a/libstockfish.so"
