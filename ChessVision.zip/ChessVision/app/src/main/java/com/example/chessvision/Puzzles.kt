package com.example.chessvision

data class Puzzle(val title: String, val theme: String, val sans: String?, val fen: String?)

object Puzzles {
    val all = listOf(
        Puzzle("Детский мат", "Мат в 1 ход", "e4 e5 Qh5 Nc6 Bc4 Nf6", null),
        Puzzle("Мат дураков", "Мат в 1 ход", "f3 e5 g4", null),
        Puzzle("Мат Легаля", "Мат в 1 ход", "e4 e5 Nf3 d6 Bc4 Bg4 Nc3 g6 Nxe5 Bxd1 Bxf7+ Ke7", null),
        Puzzle("Ловушка Блэкберна", "Мат в 1 ход", "e4 e5 Nf3 Nc6 Bc4 Nd4 Nxe5 Qg5 Nxf7 Qxg2 Rf1 Qxe4+ Be2", null),
        Puzzle("Ловушка слона", "Выиграйте материал", "d4 d5 c4 e6 Nc3 Nf6 Bg5 Nbd7 cxd5 exd5 Nxd5", null),
        Puzzle("Опера Морфи", "Мат в 2 хода", "e4 e5 Nf3 d6 d4 Bg4 dxe5 Bxf3 Qxf3 dxe5 Bc4 Nf6 Qb3 Qe7 Nc3 c6 Bg5 b5 Nxb5 cxb5 Bxb5+ Nbd7 O-O-O Rd8 Rxd7 Rxd7 Rd1 Qe6 Bxd7+ Nxd7", null),
        Puzzle("Мат по последней линии", "Мат в 1 ход", null, "6k1/5ppp/8/8/8/8/5PPP/3R2K1 w - - 0 1"),
        Puzzle("Ладья берёт ладью", "Мат в 1 ход", null, "r5k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1"),
        Puzzle("Мат конём", "Мат в 1 ход", null, "6rk/6pp/8/6N1/8/8/8/6K1 w - - 0 1")
    )
}
