package com.example.chessvision

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/** Простая шахматная доска: рисует позицию по FEN, стрелки, подсветку и принимает нажатия по клеткам. */
class BoardView(c: Context, a: AttributeSet?) : View(c, a) {
    private val pieces = CharArray(64) { ' ' }
    private var arrows: List<Triple<Int, Int, Int>> = emptyList()
    var flipped = false
        set(v) { field = v; invalidate() }
    var selected = -1
        set(v) { field = v; invalidate() }
    var lastFrom = -1
    var lastTo = -1
    var onTap: ((Int) -> Unit)? = null

    private val sq = Paint()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; style = Paint.Style.STROKE }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val headPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    fun setFen(fen: String) {
        java.util.Arrays.fill(pieces, ' ')
        val rows = fen.split(" ")[0].split("/")
        for (r in 0 until minOf(8, rows.size)) {
            val rank = 7 - r
            var file = 0
            for (ch in rows[r]) {
                if (ch.isDigit()) file += ch.digitToInt()
                else { if (file < 8) pieces[rank * 8 + file] = ch; file++ }
            }
        }
        invalidate()
    }

    fun setArrows(a: List<Triple<Int, Int, Int>>) { arrows = a; invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        val size = MeasureSpec.getSize(w)
        setMeasuredDimension(size, size)
    }

    private fun glyph(ch: Char): String {
        val g = when (ch.lowercaseChar()) {
            'k' -> "\u265A"
            'q' -> "\u265B"
            'r' -> "\u265C"
            'b' -> "\u265D"
            'n' -> "\u265E"
            else -> "\u265F"
        }
        return g + "\uFE0E"
    }

    private fun cx(idx: Int, s: Float): Float {
        val file = idx % 8
        return (if (flipped) 7 - file else file) * s + s / 2
    }

    private fun cy(idx: Int, s: Float): Float {
        val rank = idx / 8
        return (if (flipped) rank else 7 - rank) * s + s / 2
    }

    override fun onDraw(cv: Canvas) {
        val s = width / 8f
        fill.textSize = s * 0.78f
        stroke.textSize = s * 0.78f
        stroke.strokeWidth = s * 0.05f
        val fm = fill.fontMetrics
        val dy = -(fm.ascent + fm.descent) / 2f
        for (idx in 0 until 64) {
            val file = idx % 8
            val rank = idx / 8
            val x0 = (if (flipped) 7 - file else file) * s
            val y0 = (if (flipped) rank else 7 - rank) * s
            sq.color = if ((rank + file) % 2 == 1) Color.rgb(240, 217, 181) else Color.rgb(181, 136, 99)
            cv.drawRect(x0, y0, x0 + s, y0 + s, sq)
            if (idx == lastFrom || idx == lastTo) {
                sq.color = Color.argb(90, 255, 235, 59)
                cv.drawRect(x0, y0, x0 + s, y0 + s, sq)
            }
            if (idx == selected) {
                sq.color = Color.argb(130, 0, 150, 255)
                cv.drawRect(x0, y0, x0 + s, y0 + s, sq)
            }
            val ch = pieces[idx]
            if (ch != ' ') {
                val white = ch.isUpperCase()
                fill.color = if (white) Color.WHITE else Color.BLACK
                stroke.color = if (white) Color.BLACK else Color.WHITE
                val g = glyph(ch)
                val x = x0 + s / 2
                val y = y0 + s / 2 + dy
                cv.drawText(g, x, y, stroke)
                cv.drawText(g, x, y, fill)
            }
        }
        for ((from, to, color) in arrows) {
            val x1 = cx(from, s); val y1 = cy(from, s); val x2 = cx(to, s); val y2 = cy(to, s)
            linePaint.color = color; linePaint.strokeWidth = s * 0.16f
            headPaint.color = color
            val ang = atan2(y2 - y1, x2 - x1)
            val head = s * 0.5f
            cv.drawLine(x1, y1, x2 - head * 0.7f * cos(ang), y2 - head * 0.7f * sin(ang), linePaint)
            val p = Path()
            p.moveTo(x2, y2)
            p.lineTo(x2 - head * cos(ang - 0.45f), y2 - head * sin(ang - 0.45f))
            p.lineTo(x2 - head * cos(ang + 0.45f), y2 - head * sin(ang + 0.45f))
            p.close()
            cv.drawPath(p, headPaint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            val s = width / 8f
            val col = (e.x / s).toInt().coerceIn(0, 7)
            val row = (e.y / s).toInt().coerceIn(0, 7)
            val file = if (flipped) 7 - col else col
            val rank = if (flipped) row else 7 - row
            onTap?.invoke(rank * 8 + file)
            performClick()
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()
}
