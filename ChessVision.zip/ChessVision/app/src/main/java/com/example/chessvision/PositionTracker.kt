package com.example.chessvision

import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.Square
import com.github.bhlangonijr.chesslib.move.Move

/**
 * Типы фигур камера классическими методами не различает, поэтому позиция ведётся от начальной:
 * по изменению занятости/цвета клеток ищется единственный легальный ход, дающий такую картину.
 */
class PositionTracker {
    val board = Board()

    fun reset() { board.loadFromFen(SquareClassifier.START_FEN) }

    fun map(): IntArray = IntArray(64) { i ->
        val p = board.getPiece(Square.squareAt(i))
        if (p == Piece.NONE) 0 else if (p.pieceSide == Side.WHITE) 1 else 2
    }

    private fun diff(a: IntArray, b: IntArray): Int { var d = 0; for (i in 0 until 64) if (a[i] != b[i]) d++; return d }

    /** Применяет ход, лучше всего объясняющий наблюдаемую картину (допуск 1 ошибка). */
    fun match(observed: IntArray): Move? {
        val now = diff(map(), observed)
        var best: Move? = null; var bestErr = 99
        for (m in board.legalMoves()) {
            if (m.promotion != Piece.NONE && m.promotion.pieceType != PieceType.QUEEN) continue
            board.doMove(m)
            val e = diff(map(), observed)
            board.undoMove()
            if (e < bestErr) { bestErr = e; best = m }
        }
        if (best != null && bestErr <= 1 && bestErr < now) { board.doMove(best); return best }
        return null
    }
}
