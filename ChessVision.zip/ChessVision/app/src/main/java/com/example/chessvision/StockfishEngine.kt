package com.example.chessvision

import android.content.Context
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter

data class PvLine(val move: String, val cpWhite: Int)

data class Analysis(val best: String?, val scoreText: String, val cpWhite: Int = 0)

/** Запускает нативный Stockfish (libstockfish.so из jniLibs) как UCI-процесс. */
class StockfishEngine(private val ctx: Context) {
    private var proc: Process? = null
    private var out: BufferedWriter? = null
    private var inp: BufferedReader? = null

    fun start(): Boolean = try {
        val f = File(ctx.applicationInfo.nativeLibraryDir, "libstockfish.so")
        if (!f.exists()) false else {
            proc = ProcessBuilder(f.absolutePath).redirectErrorStream(true).start()
            out = BufferedWriter(OutputStreamWriter(proc!!.outputStream))
            inp = BufferedReader(InputStreamReader(proc!!.inputStream))
            send("uci"); waitFor("uciok")
            send("setoption name Threads value ${minOf(4, Runtime.getRuntime().availableProcessors())}")
            send("setoption name Hash value 64")
            send("isready"); waitFor("readyok")
            true
        }
    } catch (e: Exception) { false }

    fun setSkill(level: Int) { if (proc != null) send("setoption name Skill Level value $level") }

    /** Несколько лучших ходов (MultiPV). Оценки с точки зрения белых. */
    @Synchronized
    fun analyzeMulti(fen: String, whiteToMove: Boolean, movetimeMs: Int, n: Int): List<PvLine> {
        if (proc == null) return emptyList()
        send("setoption name MultiPV value $n")
        send("position fen $fen")
        send("go movetime $movetimeMs")
        val sign = if (whiteToMove) 1 else -1
        val map = HashMap<Int, PvLine>()
        while (true) {
            val l = inp!!.readLine() ?: break
            if (l.startsWith("info") && " multipv " in l && " score " in l && " pv " in l && "bound" !in l) {
                val t = l.split(" ")
                val k = t[t.indexOf("multipv") + 1].toIntOrNull() ?: continue
                val si = t.indexOf("score")
                val v = t.getOrNull(si + 2)?.toIntOrNull() ?: continue
                val cp = if (t[si + 1] == "mate") { if (v > 0) 10000 - v else -(10000 - Math.abs(v)) } else v
                val mv = t.getOrNull(t.indexOf("pv") + 1) ?: continue
                map[k] = PvLine(mv, cp * sign)
            } else if (l.startsWith("bestmove")) break
        }
        send("setoption name MultiPV value 1")
        return map.keys.sorted().mapNotNull { map[it] }
    }

    fun stop() { try { proc?.destroy() } catch (e: Exception) { } }

    private fun send(s: String) { out!!.write(s + "\n"); out!!.flush() }

    private fun waitFor(token: String) {
        while (true) { val l = inp!!.readLine() ?: return; if (l.startsWith(token)) return }
    }

    /** Оценка возвращается с точки зрения белых. */
    @Synchronized
    fun analyze(fen: String, whiteToMove: Boolean, movetimeMs: Int): Analysis? {
        if (proc == null) return null
        send("position fen $fen")
        send("go movetime $movetimeMs")
        var cp: Int? = null; var mate: Int? = null
        while (true) {
            val l = inp!!.readLine() ?: return null
            if (l.startsWith("info") && " score " in l && "bound" !in l) {
                val t = l.split(" ")
                val i = t.indexOf("score")
                if (i >= 0 && i + 2 < t.size) {
                    val v = t[i + 2].toIntOrNull()
                    if (t[i + 1] == "cp") { cp = v; mate = null } else if (t[i + 1] == "mate") { mate = v; cp = null }
                }
            } else if (l.startsWith("bestmove")) {
                val mv = l.split(" ").getOrNull(1)
                val sign = if (whiteToMove) 1 else -1
                val text = when {
                    mate != null -> { val m = mate * sign; if (m > 0) "#$m" else "-#${-m}" }
                    cp != null -> String.format("%+.2f", cp * sign / 100.0)
                    else -> "?"
                }
                val num = when {
                    mate != null -> { val v = if (mate > 0) 10000 - mate else -(10000 - Math.abs(mate)); v * sign }
                    cp != null -> cp * sign
                    else -> 0
                }
                return Analysis(if (mv == null || mv == "(none)") null else mv, text, num)
            }
        }
    }
}
