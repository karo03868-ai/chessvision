package com.example.chessvision

import org.opencv.core.*
import org.opencv.imgproc.Imgproc

/** Находит четырёхугольник доски и выпрямляет его в квадрат SIZE x SIZE (серый). */
class BoardDetector {

    fun detect(rgba: Mat, rMin: Double = 0.6, rMax: Double = 1.6, t1: Double = 50.0, t2: Double = 150.0): Array<Point>? {
        val gray = Mat(); val edges = Mat(); val hier = Mat()
        try {
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
            Imgproc.GaussianBlur(gray, gray, Size(5.0, 5.0), 0.0)
            Imgproc.Canny(gray, edges, t1, t2)
            Imgproc.dilate(edges, edges, Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(3.0, 3.0)))
            val contours = ArrayList<MatOfPoint>()
            Imgproc.findContours(edges, contours, hier, Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE)
            val minArea = rgba.width() * rgba.height() * 0.12
            var best: Array<Point>? = null
            var bestArea = 0.0
            for (c in contours) {
                val area = Imgproc.contourArea(c)
                if (area < minArea || area <= bestArea) continue
                val c2f = MatOfPoint2f(*c.toArray())
                val peri = Imgproc.arcLength(c2f, true)
                val approx = MatOfPoint2f()
                Imgproc.approxPolyDP(c2f, approx, 0.02 * peri, true)
                if (approx.total() != 4L) continue
                val pts = approx.toArray()
                if (!Imgproc.isContourConvex(MatOfPoint(*pts))) continue
                val o = order(pts)
                val w = dist(o[0], o[1]); val h = dist(o[0], o[3])
                val ratio = w / h
                if (ratio < rMin || ratio > rMax) continue
                best = o; bestArea = area
            }
            return best
        } finally {
            gray.release(); edges.release(); hier.release()
        }
    }

    /** Возвращает (серое выпрямленное изображение, матрица выпрямленное->кадр). */
    fun warp(rgba: Mat, quad: Array<Point>): Pair<Mat, Mat> {
        val s = SquareClassifier.SIZE.toDouble()
        val dst = MatOfPoint2f(Point(0.0, 0.0), Point(s, 0.0), Point(s, s), Point(0.0, s))
        val m = Imgproc.getPerspectiveTransform(MatOfPoint2f(*quad), dst)
        val gray = Mat(); val out = Mat()
        Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
        Imgproc.warpPerspective(gray, out, m, Size(s, s))
        gray.release()
        return Pair(out, m.inv())
    }

    fun mapPoints(inv: Mat, pts: List<Point>): List<Point> {
        val src = MatOfPoint2f(*pts.toTypedArray()); val dst = MatOfPoint2f()
        Core.perspectiveTransform(src, dst, inv)
        return dst.toList()
    }

    private fun order(p: Array<Point>): Array<Point> {
        val bySum = p.sortedBy { it.x + it.y }
        val byDiff = p.sortedBy { it.y - it.x }
        return arrayOf(bySum.first(), byDiff.first(), bySum.last(), byDiff.last()) // TL TR BR BL
    }

    private fun dist(a: Point, b: Point) = Math.hypot(a.x - b.x, a.y - b.y)
}
