package com.example.chessvision

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.imgproc.Imgproc
import java.io.File
import java.util.concurrent.Executors

class ScreenService : Service() {
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vdisplay: VirtualDisplay? = null
    private lateinit var arrowView: OverlayView
    private lateinit var panel: LinearLayout
    private lateinit var statusView: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val detector = BoardDetector()
    private val recognizer = ScreenRecognizer()
    private lateinit var engine: StockfishEngine
    @Volatile private var engineReady = false
    @Volatile private var lastFrameAt = 0L
    private var latest: Image? = null
    private val lock = Any()
    private var sw = 0; private var sh = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || projection != null) return START_NOT_STICKY
        startFg()
        val code = intent.getIntExtra("code", 0)
        @Suppress("DEPRECATION")
        val data: Intent = intent.getParcelableExtra("data") ?: run { stopSelf(); return START_NOT_STICKY }
        OpenCVLoader.initLocal()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val real = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(real)
        sw = real.widthPixels; sh = real.heightPixels
        setupCapture(code, data, real.densityDpi)
        setupOverlay()
        engine = StockfishEngine(this)
        worker.execute {
            engineReady = engine.start()
            if (!engineReady) setStatus("Нет движка Stockfish в APK")
            else loadCalibration()
        }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("cv", "ChessVision", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = Notification.Builder(this, "cv")
            .setContentTitle("ChessVision работает")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun setupCapture(code: Int, data: Intent, dpi: Int) {
        val bw = sw / 2; val bh = sh / 2
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(code, data)
        projection = mp
        mp.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, handler)
        val rd = ImageReader.newInstance(bw, bh, PixelFormat.RGBA_8888, 3)
        reader = rd
        rd.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage()
            if (img != null) {
                synchronized(lock) { latest?.close(); latest = img }
                lastFrameAt = SystemClock.uptimeMillis()
            }
        }, handler)
        vdisplay = mp.createVirtualDisplay("cv", bw, bh, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, handler)
    }

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun setupOverlay() {
        arrowView = OverlayView(this, null)
        val lp1 = WindowManager.LayoutParams(
            sw, sh, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(arrowView, lp1)

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(210, 20, 20, 20))
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }
        statusView = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f; text = "ChessVision: начальная позиция → «Калибр.»" }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(t: String, a: () -> Unit) = Button(this).apply {
            text = t; textSize = 12f; isAllCaps = false; minWidth = 0; minimumWidth = 0
            setPadding(dp(8), 0, dp(8), 0); setOnClickListener { a() }
        }
        row.addView(btn("Калибр.") { captureThen { doCalibrate(it) } })
        row.addView(btn("Ход") { captureThen { doMove(it) } })
        row.addView(btn("✕") { stopSelf() })
        panel.addView(statusView); panel.addView(row)
        val lp2 = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; y = dp(60) }
        wm.addView(panel, lp2)
    }

    private fun setStatus(s: String) { handler.post { statusView.text = s } }

    /** Прячет наши окна, ждёт свежий кадр экрана без них, возвращает окна и отдаёт кадр в обработку. */
    private fun captureThen(action: (Bitmap) -> Unit) {
        arrowView.update(1, 1, null, null)
        arrowView.visibility = View.INVISIBLE
        panel.visibility = View.INVISIBLE
        val t0 = SystemClock.uptimeMillis()
        fun poll() {
            val now = SystemClock.uptimeMillis()
            if (lastFrameAt > t0 + 80 || now - t0 > 900) {
                val bmp = synchronized(lock) { latest?.let { toBitmap(it) } }
                panel.visibility = View.VISIBLE; arrowView.visibility = View.VISIBLE
                if (bmp == null) setStatus("Нет кадра экрана") else { setStatus("Анализ…"); worker.execute { action(bmp) } }
            } else handler.postDelayed({ poll() }, 40)
        }
        handler.postDelayed({ poll() }, 120)
    }

    private fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        val pad = p.rowStride - p.pixelStride * img.width
        val bmp = Bitmap.createBitmap(img.width + pad / p.pixelStride, img.height, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(p.buffer)
        return if (pad == 0) bmp else Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
    }

    private fun withBoard(bmp: Bitmap, block: (Mat, Mat) -> Unit) {
        val rgba = Mat()
        Utils.bitmapToMat(bmp, rgba)
        try {
            val quad = detector.detect(rgba, 0.9, 1.1, 30.0, 90.0)
            if (quad == null) { setStatus("Доска не найдена. Откройте партию, доска должна быть на экране"); return }
            val (g, inv) = detector.warp(rgba, quad)
            try { block(g, inv) } finally { g.release(); inv.release() }
        } finally { rgba.release() }
    }

    private fun doCalibrate(bmp: Bitmap) = withBoard(bmp) { g, _ ->
        if (recognizer.calibrate(g)) {
            val out = Bitmap.createBitmap(g.cols(), g.rows(), Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(g, out)
            File(filesDir, "start.png").outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            setStatus("Калибровка готова. Когда ваш ход, жмите «Ход»")
        } else setStatus("Калибровка не удалась: нужна начальная позиция на экране")
    }

    private fun loadCalibration() {
        val f = File(filesDir, "start.png")
        if (!f.exists()) return
        val bm = BitmapFactory.decodeFile(f.absolutePath) ?: return
        val m = Mat(); val g = Mat()
        Utils.bitmapToMat(bm, m)
        Imgproc.cvtColor(m, g, Imgproc.COLOR_RGBA2GRAY)
        if (recognizer.calibrate(g)) setStatus("Калибровка загружена. Жмите «Ход»")
        m.release(); g.release()
    }

    private fun idx(s: String) = (s[1] - '1') * 8 + (s[0] - 'a')

    private fun center(i: Int): Point {
        val (r, c) = recognizer.cellOf(i)
        val cell = SquareClassifier.CELL
        return Point(c * cell + cell / 2.0, r * cell + cell / 2.0)
    }

    private fun doMove(bmp: Bitmap) = withBoard(bmp) { g, inv ->
        if (!recognizer.calibrated) { setStatus("Сначала калибровка в начальной позиции"); return@withBoard }
        val fen = recognizer.toFen(g) ?: run { setStatus("Позиция не распознана. Перекалибруйте (тема фигур?)"); return@withBoard }
        if (!engineReady) { setStatus("Нет движка Stockfish"); return@withBoard }
        val white = fen.split(" ")[1] == "w"
        val r = engine.analyze(fen, white, 1000) ?: run { setStatus("Ошибка движка"); return@withBoard }
        val mv = r.best ?: run { setStatus("Ходов нет (${r.scoreText})"); return@withBoard }
        val p = detector.mapPoints(inv, listOf(center(idx(mv.substring(0, 2))), center(idx(mv.substring(2, 4)))))
        val arrow = floatArrayOf(p[0].x.toFloat(), p[0].y.toFloat(), p[1].x.toFloat(), p[1].y.toFloat())
        handler.post { arrowView.update(bmp.width, bmp.height, null, arrow) }
        setStatus("${mv.substring(0, 2)} → ${mv.substring(2, 4)}   оценка (белые) ${r.scoreText}")
    }

    override fun onDestroy() {
        super.onDestroy()
        try { wm.removeView(arrowView); wm.removeView(panel) } catch (e: Exception) { }
        vdisplay?.release(); reader?.close(); projection?.stop()
        if (::engine.isInitialized) engine.stop()
        worker.shutdown()
    }
}
