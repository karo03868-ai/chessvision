package com.example.chessvision

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/** График оценки партии. Выше середины лучше белым, ниже лучше чёрным. */
class EvalChartView(c: Context, a: AttributeSet?) : View(c, a) {
    private var data = IntArray(0)
    private var cur = -1
    var onPick: ((Int) -> Unit)? = null
    private val bg = Paint().apply { color = Color.rgb(40, 40, 40) }
    private val mid = Paint().apply { color = Color.GRAY; strokeWidth = 2f }
    private val ln = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeWidth = 4f; style = Paint.Style.STROKE }
    private val mark = Paint().apply { color = Color.rgb(255, 193, 7); strokeWidth = 4f }

    fun setData(d: IntArray) { data = d; cur = -1; invalidate() }
    fun setCurrent(i: Int) { cur = i; invalidate() }

    private fun xOf(i: Int): Float = if (data.size <= 1) 0f else i * (width.toFloat() / (data.size - 1))
    private fun yOf(v: Int): Float {
        val c = v.coerceIn(-500, 500) / 500f
        return height / 2f - c * (height / 2f - 3f)
    }

    override fun onDraw(cv: Canvas) {
        cv.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        cv.drawLine(0f, height / 2f, width.toFloat(), height / 2f, mid)
        for (i in 1 until data.size) cv.drawLine(xOf(i - 1), yOf(data[i - 1]), xOf(i), yOf(data[i]), ln)
        if (cur in data.indices) cv.drawLine(xOf(cur), 0f, xOf(cur), height.toFloat(), mark)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (data.size > 1 && (e.action == MotionEvent.ACTION_DOWN || e.action == MotionEvent.ACTION_MOVE || e.action == MotionEvent.ACTION_UP)) {
            val i = Math.round(e.x / width * (data.size - 1)).coerceIn(0, data.size - 1)
            onPick?.invoke(i)
            if (e.action == MotionEvent.ACTION_UP) performClick()
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()
}
