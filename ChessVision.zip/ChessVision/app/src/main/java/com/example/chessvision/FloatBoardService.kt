package com.example.chessvision

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.Square
import java.util.concurrent.Executors

/** Плавающая шахматная доска поверх других приложений. Ходы делаете вы сами, Stockfish показывает лучший ход стрелкой. */
class FloatBoardService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var boardView: BoardView
    private lateinit var statusView: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var engine: StockfishEngine
    @Volatile private var engineReady = false
    @Volatile private var seq = 0
    private val board = Board()
    private var selected = -1
    private var plies = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        if (::root.isInitialized) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildWindow()
        engine = StockfishEngine(this)
        board.loadFromFen(SquareClassifier.START_FEN)
        boardView.setFen(board.fen)
        worker.execute {
            engineReady = engine.start()
            handler.post { if (engineReady) analyze() else statusView.text = "Нет движка Stockfish" }
        }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("cv", "ChessVision", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = Notification.Builder(this, "cv")
            .setContentTitle("Плавающая доска ChessVision")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(2, n)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildWindow() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(235, 25, 25, 25))
            setPadding(dp(6), dp(4), dp(6), dp(6))
        }
        statusView = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f; text = "Тяните за этот текст, чтобы двигать окно" }
        root.addView(statusView, LinearLayout.LayoutParams(dp(280), LinearLayout.LayoutParams.WRAP_CONTENT))

        boardView = BoardView(this, null)
        boardView.onTap = { tap(it) }
        root.addView(boardView, LinearLayout.LayoutParams(dp(280), dp(280)))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(t: String, a: () -> Unit) = Button(this).apply {
            text = t; textSize = 11f; isAllCaps = false; minWidth = 0; minimumWidth = 0
            setPadding(dp(2), 0, dp(2), 0); setOnClickListener { a() }
        }
        val lp = { LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) }
        row.addView(btn("Сброс") { reset() }, lp())
        row.addView(btn("←") { undo() }, lp())
        row.addView(btn("⇅") { boardView.flipped = !boardView.flipped }, lp())
        row.addView(btn("Встав.") { paste() }, lp())
        row.addView(btn("▢") {
            boardView.visibility = if (boardView.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }, lp())
        row.addView(btn("✕") { stopSelf() }, lp())
        root.addView(row, LinearLayout.LayoutParams(dp(280), LinearLayout.LayoutParams.WRAP_CONTENT))

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(10); y = dp(120) }

        var sx = 0f; var sy = 0f; var px = 0; var py = 0
        statusView.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; px = params.x; py = params.y }
                MotionEvent.ACTION_MOVE -> {
                    params.x = px + (e.rawX - sx).toInt()
                    params.y = py + (e.rawY - sy).toInt()
                    wm.updateViewLayout(root, params)
                }
            }
            true
        }
        wm.addView(root, params)
    }

    private fun refresh() {
        selected = -1; boardView.selected = -1
        boardView.setFen(board.fen)
        analyze()
    }

    private fun reset() {
        board.loadFromFen(SquareClassifier.START_FEN)
        plies = 0
        boardView.lastFrom = -1; boardView.lastTo = -1
        refresh()
    }

    private fun undo() {
        if (plies <= 0) return
        board.undoMove(); plies--
        boardView.lastFrom = -1; boardView.lastTo = -1
        refresh()
    }

    private fun paste() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim()
        if (t.isNullOrEmpty()) { statusView.text = "Буфер обмена пуст"; return }
        try {
            val nb = Board()
            if (t.count { it == '/' } == 7 && !t.contains("[")) {
                val f = t.lines().first().trim()
                nb.loadFromFen(if (f.contains(" ")) f else "$f w - - 0 1")
            } else {
                for (tok in San.tokens(t)) {
                    val m = San.toMove(nb, tok) ?: break
                    nb.doMove(m)
                }
            }
            board.loadFromFen(nb.fen)
            plies = 0
            boardView.lastFrom = -1; boardView.lastTo = -1
            refresh()
        } catch (e: Exception) {
            statusView.text = "Не удалось прочитать FEN или партию"
        }
    }

    private fun tap(idx: Int) {
        val p = board.getPiece(Square.squareAt(idx))
        val mine = p != Piece.NONE && p.pieceSide == board.sideToMove
        if (selected < 0) {
            if (mine) { selected = idx; boardView.selected = idx }
            return
        }
        if (idx == selected) { selected = -1; boardView.selected = -1; return }
        if (mine) { selected = idx; boardView.selected = idx; return }
        val from = selected
        selected = -1; boardView.selected = -1
        val cand = board.legalMoves().filter { San.idx(it.from) == from && San.idx(it.to) == idx }
        if (cand.isEmpty()) { statusView.text = "Так ходить нельзя"; return }
        val m = cand.firstOrNull { it.promotion != Piece.NONE && it.promotion.pieceType == PieceType.QUEEN } ?: cand[0]
        board.doMove(m)
        plies++
        boardView.lastFrom = San.idx(m.from)
        boardView.lastTo = San.idx(m.to)
        refresh()
    }

    private fun analyze() {
        val my = ++seq
        boardView.setArrows(emptyList())
        if (board.legalMoves().isEmpty()) {
            statusView.text = if (board.isKingAttacked) "Мат" else "Пат — ничья"
            return
        }
        val fen = board.fen
        val wtm = board.sideToMove == Side.WHITE
        statusView.text = (if (wtm) "Ход белых" else "Ход чёрных") + ": считаю…"
        if (!engineReady) return
        worker.execute {
            val a = engine.analyze(fen, wtm, 1000)
            handler.post {
                if (my != seq) return@post
                val a2 = a ?: return@post
                val u = a2.best ?: return@post
                boardView.setArrows(listOf(Triple(San.idx(u.substring(0, 2)), San.idx(u.substring(2, 4)), Color.argb(220, 0, 200, 0))))
                statusView.text = (if (wtm) "Белые: " else "Чёрные: ") + u.substring(0, 2) + "→" + u.substring(2, 4) +
                    "   оценка (белые) " + a2.scoreText
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        seq++
        try { if (::root.isInitialized) wm.removeView(root) } catch (e: Exception) { }
        if (::engine.isInitialized) engine.stop()
        worker.shutdown()
    }
}
