package com.example.chessvision

import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.Square
import com.github.bhlangonijr.chesslib.move.Move

object San {
    fun idx(sq: Square): Int = idx(sq.name.lowercase())
    fun idx(s: String): Int = (s[1] - '1') * 8 + (s[0] - 'a')

    private fun letter(pt: PieceType): Char = when (pt) {
        PieceType.KNIGHT -> 'N'
        PieceType.BISHOP -> 'B'
        PieceType.ROOK -> 'R'
        PieceType.QUEEN -> 'Q'
        PieceType.KING -> 'K'
        else -> 'P'
    }

    fun uci(m: Move): String {
        var u = m.from.name.lowercase() + m.to.name.lowercase()
        if (m.promotion != Piece.NONE) u += letter(m.promotion.pieceType).lowercaseChar()
        return u
    }

    /** Находит легальный ход по записи SAN (e4, Nf3, exd5, O-O, e8=Q ...). */
    fun toMove(board: Board, raw: String): Move? {
        var t = raw.replace("+", "").replace("#", "").replace("!", "").replace("?", "").trim()
        if (t.isEmpty()) return null
        val legal = board.legalMoves()
        val white = board.sideToMove == Side.WHITE
        if (t.startsWith("O") || t.startsWith("0")) {
            val kingside = t.length <= 3
            val target = (if (kingside) "g" else "c") + (if (white) "1" else "8")
            return legal.firstOrNull {
                board.getPiece(it.from).pieceType == PieceType.KING &&
                    it.from.name.lowercase()[0] == 'e' && it.to.name.lowercase() == target
            }
        }
        var promo: Char? = null
        val eq = t.indexOf('=')
        if (eq >= 0 && eq + 1 < t.length) {
            promo = t[eq + 1].uppercaseChar(); t = t.substring(0, eq)
        } else if (t.length >= 3 && t.last() in "QRBN" && t[t.length - 2].isDigit()) {
            promo = t.last(); t = t.dropLast(1)
        }
        var type = PieceType.PAWN
        if (t[0] in "KQRBN") {
            type = when (t[0]) {
                'K' -> PieceType.KING
                'Q' -> PieceType.QUEEN
                'R' -> PieceType.ROOK
                'B' -> PieceType.BISHOP
                else -> PieceType.KNIGHT
            }
            t = t.substring(1)
        }
        t = t.replace("x", "").replace("-", "")
        if (t.length < 2) return null
        val dest = t.takeLast(2)
        val dis = t.dropLast(2)
        val ty = type
        val pr = promo
        return legal.firstOrNull { m ->
            val f = m.from.name.lowercase()
            board.getPiece(m.from).pieceType == ty &&
                m.to.name.lowercase() == dest &&
                (if (pr != null) (m.promotion != Piece.NONE && letter(m.promotion.pieceType) == pr) else m.promotion == Piece.NONE) &&
                dis.all { c -> if (c in 'a'..'h') f[0] == c else f[1] == c }
        }
    }


    /** Запись хода в SAN (e4, Nbd7, exd5, O-O, e8=Q+). Вызывать до того, как ход сделан на доске. */
    fun toSan(board: Board, m: Move): String {
        val pt = board.getPiece(m.from).pieceType
        val from = m.from.name.lowercase()
        val to = m.to.name.lowercase()
        val capture = board.getPiece(m.to) != Piece.NONE || (pt == PieceType.PAWN && from[0] != to[0])
        var s: String
        if (pt == PieceType.KING && Math.abs(from[0] - to[0]) == 2) {
            s = if (to[0] == 'g') "O-O" else "O-O-O"
        } else {
            val sb = StringBuilder()
            if (pt != PieceType.PAWN) {
                sb.append(letter(pt))
                val others = board.legalMoves().filter {
                    !(it.from == m.from && it.to == m.to && it.promotion == m.promotion) &&
                        board.getPiece(it.from).pieceType == pt && it.to == m.to
                }
                if (others.isNotEmpty()) {
                    val sameFile = others.any { it.from.name.lowercase()[0] == from[0] }
                    val sameRank = others.any { it.from.name.lowercase()[1] == from[1] }
                    if (!sameFile) sb.append(from[0]) else if (!sameRank) sb.append(from[1]) else sb.append(from)
                }
            } else if (capture) sb.append(from[0])
            if (capture) sb.append('x')
            sb.append(to)
            if (m.promotion != Piece.NONE) sb.append('=').append(letter(m.promotion.pieceType))
            s = sb.toString()
        }
        board.doMove(m)
        val check = board.isKingAttacked
        val mated = check && board.legalMoves().isEmpty()
        board.undoMove()
        if (mated) s += "#" else if (check) s += "+"
        return s
    }

    /** Из текста PGN оставляет только ходы. */
    fun tokens(pgn: String): List<String> {
        var s = pgn.replace(Regex("\\[[^\\]]*\\]"), " ")
        s = s.replace(Regex("\\{[^}]*\\}"), " ")
        s = s.replace(Regex(";[^\\n]*"), " ")
        var prev: String
        do { prev = s; s = s.replace(Regex("\\([^()]*\\)"), " ") } while (s != prev)
        s = s.replace(Regex("[$]\\d+"), " ")
        s = s.replace(Regex("\\d+\\.(\\.\\.)?"), " ")
        val skip = setOf("1-0", "0-1", "1/2-1/2", "*")
        return s.split(Regex("\\s+")).filter { it.isNotEmpty() && it !in skip }
    }
}
