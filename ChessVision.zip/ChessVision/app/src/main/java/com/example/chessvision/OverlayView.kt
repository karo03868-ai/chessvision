package com.example.chessvision

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class OverlayView(c: Context, a: AttributeSet?) : View(c, a) {
    private var iw = 1; private var ih = 1
    private var quad: FloatArray? = null
    private var arrow: FloatArray? = null
    private val quadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.CYAN; style = Paint.Style.STROKE; strokeWidth = 4f }
    private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(220, 0, 200, 0); style = Paint.Style.STROKE; strokeWidth = 14f; strokeCap = Paint.Cap.ROUND }
    private val headPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(220, 0, 200, 0); style = Paint.Style.FILL }

    /** quad: 8 чисел (TL,TR,BR,BL) в координатах кадра; arrow: x1,y1,x2,y2 в координатах кадра. */
    fun update(w: Int, h: Int, q: FloatArray?, a: FloatArray?) {
        iw = w; ih = h; quad = q; arrow = a; postInvalidate()
    }

    override fun onDraw(cv: Canvas) {
        val s = min(width / iw.toFloat(), height / ih.toFloat())
        val ox = (width - iw * s) / 2f; val oy = (height - ih * s) / 2f
        quad?.let { q ->
            for (i in 0 until 4) {
                val j = (i + 1) % 4
                cv.drawLine(ox + q[i * 2] * s, oy + q[i * 2 + 1] * s, ox + q[j * 2] * s, oy + q[j * 2 + 1] * s, quadPaint)
            }
        }
        arrow?.let { a ->
            val x1 = ox + a[0] * s; val y1 = oy + a[1] * s; val x2 = ox + a[2] * s; val y2 = oy + a[3] * s
            val ang = atan2(y2 - y1, x2 - x1); val head = 46f
            val bx = x2 - head * 0.8f * cos(ang); val by = y2 - head * 0.8f * sin(ang)
            cv.drawLine(x1, y1, bx, by, arrowPaint)
            val p = Path()
            p.moveTo(x2, y2)
            p.lineTo(x2 - head * cos(ang - 0.45f), y2 - head * sin(ang - 0.45f))
            p.lineTo(x2 - head * cos(ang + 0.45f), y2 - head * sin(ang + 0.45f))
            p.close(); cv.drawPath(p, headPaint)
        }
    }
}
