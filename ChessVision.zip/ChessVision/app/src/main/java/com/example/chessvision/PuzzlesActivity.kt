package com.example.chessvision

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.Square
import java.util.concurrent.Executors

/** Задачи: верный ответ определяет Stockfish (лучший ход или ход, не хуже лучшего более чем на 0.8). */
class PuzzlesActivity : AppCompatActivity() {
    private val board = Board()
    private lateinit var boardView: BoardView
    private lateinit var msg: TextView
    private lateinit var info: TextView
    private lateinit var engine: StockfishEngine
    private val worker = Executors.newSingleThreadExecutor()
    private var index = 0
    private var solved = 0
    private var done = true
    private var selected = -1
    private var ready = false
    private var checking = false
    private var bestUci: String? = null
    private var bestEval = 0
    private var moverWhite = true
    @Volatile private var token = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_puzzles)
        boardView = findViewById(R.id.board)
        msg = findViewById(R.id.msg)
        info = findViewById(R.id.info)
        engine = StockfishEngine(this)
        worker.execute {
            if (!engine.start()) runOnUiThread { msg.text = "Нет движка Stockfish в приложении" }
        }
        findViewById<Button>(R.id.btnNext).setOnClickListener { index = (index + 1) % Puzzles.all.size; load() }
        findViewById<Button>(R.id.btnHint).setOnClickListener { hint() }
        boardView.onTap = { tap(it) }
        load()
    }

    private fun arrow(u: String) = u.substring(0, 2) + "→" + u.substring(2, 4)

    private fun load() {
        val my = ++token
        val p = Puzzles.all[index]
        board.loadFromFen(p.fen ?: SquareClassifier.START_FEN)
        if (p.sans != null) {
            for (t in p.sans.split(" ")) {
                val m = San.toMove(board, t) ?: break
                board.doMove(m)
            }
        }
        moverWhite = board.sideToMove == Side.WHITE
        selected = -1; done = false; ready = false; checking = false; bestUci = null
        boardView.flipped = !moverWhite
        boardView.selected = -1
        boardView.lastFrom = -1; boardView.lastTo = -1
        boardView.setArrows(emptyList())
        boardView.setFen(board.fen)
        info.text = "Задача ${index + 1}/${Puzzles.all.size}: ${p.title}. ${p.theme}. Решено: $solved"
        msg.text = "Загрузка…"
        val fen = board.fen
        val wtm = moverWhite
        worker.execute {
            val a = engine.analyze(fen, wtm, 1000)
            runOnUiThread {
                if (my != token) return@runOnUiThread
                if (a == null) { msg.text = "Движок недоступен"; return@runOnUiThread }
                bestUci = a.best
                bestEval = a.cpWhite * (if (wtm) 1 else -1)
                ready = true
                msg.text = if (wtm) "Ход белых. Найдите лучший ход" else "Ход чёрных. Найдите лучший ход"
            }
        }
    }

    private fun tap(idx: Int) {
        if (done || !ready || checking) return
        val side = if (moverWhite) Side.WHITE else Side.BLACK
        val p = board.getPiece(Square.squareAt(idx))
        val mine = p != Piece.NONE && p.pieceSide == side
        if (selected < 0) {
            if (mine) { selected = idx; boardView.selected = idx }
            return
        }
        if (idx == selected) { selected = -1; boardView.selected = -1; return }
        if (mine) { selected = idx; boardView.selected = idx; return }
        val from = selected
        selected = -1; boardView.selected = -1
        val cand = board.legalMoves().filter { San.idx(it.from) == from && San.idx(it.to) == idx }
        if (cand.isEmpty()) { msg.text = "Так ходить нельзя"; return }
        val m = cand.firstOrNull { it.promotion != Piece.NONE && it.promotion.pieceType == PieceType.QUEEN } ?: cand[0]
        val u = San.uci(m)
        val after = Board()
        after.loadFromFen(board.fen)
        after.doMove(m)
        if (u == bestUci || (after.legalMoves().isEmpty() && after.isKingAttacked)) { accept(m); return }
        checking = true
        msg.text = "Проверяю…"
        val my = token
        val fenAfter = after.fen
        val whiteAfter = after.sideToMove == Side.WHITE
        worker.execute {
            val a = engine.analyze(fenAfter, whiteAfter, 500)
            runOnUiThread {
                if (my != token) return@runOnUiThread
                checking = false
                val ev = (a?.cpWhite ?: -10000) * (if (moverWhite) 1 else -1)
                val ok = if (bestEval >= 9000) ev >= 9000 else bestEval - ev <= 80
                if (ok) accept(m) else msg.text = "Неверно. Попробуйте ещё раз"
            }
        }
    }

    private fun accept(m: com.github.bhlangonijr.chesslib.move.Move) {
        board.doMove(m)
        boardView.lastFrom = San.idx(m.from)
        boardView.lastTo = San.idx(m.to)
        boardView.setArrows(emptyList())
        boardView.setFen(board.fen)
        done = true
        solved++
        val p = Puzzles.all[index]
        info.text = "Задача ${index + 1}/${Puzzles.all.size}: ${p.title}. ${p.theme}. Решено: $solved"
        msg.text = "Верно! ✓ Нажмите «Следующая»"
    }

    private fun hint() {
        val u = bestUci
        if (done || !ready || u == null) return
        boardView.setArrows(listOf(Triple(San.idx(u.substring(0, 2)), San.idx(u.substring(2, 4)), Color.argb(220, 0, 200, 0))))
        msg.text = "Подсказка: " + arrow(u)
    }

    override fun onDestroy() {
        super.onDestroy()
        token++
        if (::engine.isInitialized) engine.stop()
        worker.shutdown()
    }
}
