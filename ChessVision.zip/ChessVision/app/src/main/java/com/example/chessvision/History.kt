package com.example.chessvision

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Хранилище сыгранных партий: каждая партия это файл PGN во внутренней папке приложения. */
object History {
    class Item(val file: File, val title: String, val pgn: String)

    private fun dir(c: Context): File {
        val d = File(c.filesDir, "games")
        d.mkdirs()
        return d
    }

    fun save(c: Context, pgn: String) {
        File(dir(c), System.currentTimeMillis().toString() + ".pgn").writeText(pgn)
    }

    private fun tag(pgn: String, name: String): String =
        Regex("\\[" + name + " \"([^\"]*)\"\\]").find(pgn)?.groupValues?.get(1) ?: ""

    fun list(c: Context): List<Item> {
        val files = dir(c).listFiles() ?: return emptyList()
        return files.filter { it.name.endsWith(".pgn") }.sortedByDescending { it.name }.map { f ->
            val pgn = f.readText()
            val ts = f.name.removeSuffix(".pgn").toLongOrNull() ?: 0L
            val date = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(ts))
            val moves = (San.tokens(pgn).size + 1) / 2
            val res = tag(pgn, "Result")
            val title = date + "\n" + tag(pgn, "White") + " — " + tag(pgn, "Black") + "\nРезультат: " +
                (if (res == "*") "не закончена" else res) + ", ходов: " + moves
            Item(f, title, pgn)
        }
    }
}
