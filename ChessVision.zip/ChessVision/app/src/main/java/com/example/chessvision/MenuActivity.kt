package com.example.chessvision

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MenuActivity : AppCompatActivity() {
    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            val i = Intent(this, ScreenService::class.java).putExtra("code", r.resultCode).putExtra("data", data)
            ContextCompat.startForegroundService(this, i)
            Toast.makeText(this, "Откройте Chess.com/Lichess: поверх появится панель", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)
        findViewById<Button>(R.id.btnScreen).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Разрешите «Поверх других окон» и нажмите снова", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projLauncher.launch(mpm.createScreenCaptureIntent())
            }
        }
        findViewById<Button>(R.id.btnTrainer).setOnClickListener { startActivity(Intent(this, TrainerActivity::class.java)) }
        findViewById<Button>(R.id.btnReview).setOnClickListener { startActivity(Intent(this, ReviewActivity::class.java)) }
        findViewById<Button>(R.id.btnCamera).setOnClickListener { startActivity(Intent(this, MainActivity::class.java)) }
    }
}
