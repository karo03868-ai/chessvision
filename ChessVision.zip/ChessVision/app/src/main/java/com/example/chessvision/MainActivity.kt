package com.example.chessvision

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.AspectRatio
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.github.bhlangonijr.chesslib.Side
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Mat
import org.opencv.core.Point
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var overlay: OverlayView
    private lateinit var statusText: TextView
    private lateinit var moveText: TextView
    private lateinit var btnFlip: Button

    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val engineExecutor = Executors.newSingleThreadExecutor()
    private val detector = BoardDetector()
    private val classifier = SquareClassifier()
    private val tracker = PositionTracker()
    private lateinit var engine: StockfishEngine
    @Volatile private var engineReady = false

    @Volatile private var calibrateRequested = false
    @Volatile private var resetRequested = false
    @Volatile private var flipped = false
    @Volatile private var calibrated = false
    @Volatile private var bestMove: String? = null
    @Volatile private var analysisSeq = 0

    private var candidate: IntArray? = null
    private var stable = 0
    private var lastQuad: Array<Point>? = null
    private var misses = 0
    private var lastFrame = 0L

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) startCamera() else status("Нужен доступ к камере")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        previewView = findViewById(R.id.previewView)
        previewView.scaleType = PreviewView.ScaleType.FIT_CENTER
        overlay = findViewById(R.id.overlay)
        statusText = findViewById(R.id.statusText)
        moveText = findViewById(R.id.moveText)
        btnFlip = findViewById(R.id.btnFlip)
        findViewById<Button>(R.id.btnCalibrate).setOnClickListener { calibrateRequested = true }
        findViewById<Button>(R.id.btnReset).setOnClickListener { resetRequested = true }
        btnFlip.setOnClickListener {
            flipped = !flipped; calibrated = false
            btnFlip.text = if (flipped) "Белые снизу" else "Чёрные снизу"
            status("Ориентация изменена — нажмите «Калибровка»")
        }

        if (!OpenCVLoader.initLocal()) { status("Не удалось загрузить OpenCV"); return }
        tracker.reset()
        engine = StockfishEngine(this)
        engineExecutor.execute {
            engineReady = engine.start()
            if (!engineReady) status("Нет libstockfish.so: запустите scripts/fetch_stockfish.sh и пересоберите")
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else permLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun status(s: String) = runOnUiThread { statusText.text = s }

    @Suppress("DEPRECATION")
    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().setTargetAspectRatio(AspectRatio.RATIO_4_3).build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(cameraExecutor) { proxy ->
                try { analyzeFrame(proxy) } catch (e: Exception) { status("Ошибка: ${e.message}") } finally { proxy.close() }
            }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyzeFrame(proxy: ImageProxy) {
        val now = System.currentTimeMillis()
        if (now - lastFrame < 150) return
        lastFrame = now
        var bmp: Bitmap = proxy.toBitmap()
        val deg = proxy.imageInfo.rotationDegrees
        if (deg != 0) {
            val m = Matrix(); m.postRotate(deg.toFloat())
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        val rgba = Mat()
        Utils.bitmapToMat(bmp, rgba)
        try { process(rgba, bmp.width, bmp.height) } finally { rgba.release() }
    }

    private fun process(rgba: Mat, w: Int, h: Int) {
        if (resetRequested) {
            resetRequested = false; calibrated = false; bestMove = null; candidate = null
            tracker.reset(); runOnUiThread { moveText.text = "—" }
            status("Сброс. Поставьте начальную позицию и нажмите «Калибровка»")
        }
        var quad = detector.detect(rgba)
        if (quad != null) { lastQuad = quad; misses = 0 }
        else if (++misses <= 10) quad = lastQuad else lastQuad = null
        if (quad == null) { overlay.update(w, h, null, null); if (!calibrated) status("Доска не найдена"); return }

        val (warped, inv) = detector.warp(rgba, quad)
        try {
            if (calibrateRequested) {
                calibrateRequested = false
                if (classifier.calibrate(warped, flipped)) {
                    calibrated = true; tracker.reset(); candidate = null; stable = 0
                    status("Калибровка выполнена. Играйте!"); analyzeFen()
                } else status("Калибровка не удалась: наведите на доску с начальной позицией (белые снизу/сверху — см. кнопку)")
            } else if (calibrated) track(warped)
        } finally { warped.release() }

        var arrow: FloatArray? = null
        val mv = bestMove
        if (calibrated && mv != null && mv.length >= 4) {
            val a = squareIndex(mv.substring(0, 2)); val b = squareIndex(mv.substring(2, 4))
            val pts = listOf(center(a), center(b))
            val p = detector.mapPoints(inv, pts)
            arrow = floatArrayOf(p[0].x.toFloat(), p[0].y.toFloat(), p[1].x.toFloat(), p[1].y.toFloat())
        }
        inv.release()
        val q = FloatArray(8) { i -> (if (i % 2 == 0) quad[i / 2].x else quad[i / 2].y).toFloat() }
        overlay.update(w, h, q, arrow)
    }

    private fun squareIndex(s: String) = (s[1] - '1') * 8 + (s[0] - 'a')

    private fun center(idx: Int): Point {
        val (row, col) = classifier.cellOf(idx, flipped)
        return Point(col * SquareClassifier.CELL + SquareClassifier.CELL / 2.0, row * SquareClassifier.CELL + SquareClassifier.CELL / 2.0)
    }

    private fun track(warped: Mat) {
        val observed = classifier.read(warped, flipped)
        val expected = tracker.map()
        if (classifier.diff(observed, expected) == 0) { candidate = null; stable = 0; return }
        val c = candidate
        if (c != null && classifier.diff(c, observed) == 0) stable++ else { candidate = observed; stable = 1 }
        if (stable >= 4) {
            stable = 0
            val mv = tracker.match(observed)
            if (mv != null) {
                status("Обнаружен ход: $mv"); bestMove = null; analyzeFen()
            } else status("Позиция не распознана: уберите руки и проверьте освещение")
        }
    }

    private fun analyzeFen() {
        val fen = tracker.board.fen
        val whiteToMove = tracker.board.sideToMove == Side.WHITE
        val seq = ++analysisSeq
        engineExecutor.execute {
            if (!engineReady) return@execute
            val r = engine.analyze(fen, whiteToMove, 1000) ?: return@execute
            if (seq != analysisSeq) return@execute
            bestMove = r.best
            runOnUiThread {
                moveText.text = if (r.best == null) "Игра окончена (${r.scoreText})"
                else "Лучший ход: ${r.best.substring(0, 2)} → ${r.best.substring(2, 4)}   оценка ${r.scoreText}"
            }
        }
    }

    override fun onDestroy() { super.onDestroy(); cameraExecutor.shutdown(); engineExecutor.shutdown() }
}
