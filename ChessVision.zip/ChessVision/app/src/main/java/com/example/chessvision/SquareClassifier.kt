package com.example.chessvision

import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.MatOfDouble
import org.opencv.core.Rect
import kotlin.math.abs

/**
 * По выпрямленному изображению определяет для каждой клетки: 0 пусто, 1 белая фигура, 2 чёрная.
 * Пороги калибруются по начальной позиции.
 */
class SquareClassifier {
    companion object {
        const val SIZE = 400
        const val CELL = SIZE / 8
        const val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
    }

    private val emptyMean = DoubleArray(2)
    private val emptyStd = DoubleArray(2)
    private var pieceThr = 128.0
    private var whiteBrighter = true

    /** idx = rank*8+file (a1=0). Возвращает (row, col) клетки на выпрямленном изображении. */
    fun cellOf(idx: Int, flipped: Boolean): Pair<Int, Int> {
        val file = idx % 8; val rank = idx / 8
        return if (flipped) Pair(rank, 7 - file) else Pair(7 - rank, file)
    }

    private fun stats(g: Mat, row: Int, col: Int, pad: Int): DoubleArray {
        val roi = g.submat(Rect(col * CELL + pad, row * CELL + pad, CELL - 2 * pad, CELL - 2 * pad))
        val m = MatOfDouble(); val s = MatOfDouble()
        Core.meanStdDev(roi, m, s)
        val r = doubleArrayOf(m.get(0, 0)[0], s.get(0, 0)[0])
        roi.release(); m.release(); s.release()
        return r
    }

    /** Доска должна стоять в начальной позиции. Возвращает true, если калибровка правдоподобна. */
    fun calibrate(g: Mat, flipped: Boolean): Boolean {
        val sm = DoubleArray(2); val ss = DoubleArray(2); val n = IntArray(2)
        for (row in 2..5) for (col in 0..7) {
            val st = stats(g, row, col, 8); val c = (row + col) % 2
            sm[c] += st[0]; ss[c] += st[1]; n[c]++
        }
        for (c in 0..1) { emptyMean[c] = sm[c] / n[c]; emptyStd[c] = ss[c] / n[c] }
        var top = 0.0; var bottom = 0.0
        for (row in listOf(0, 1)) for (col in 0..7) top += stats(g, row, col, 17)[0]
        for (row in listOf(6, 7)) for (col in 0..7) bottom += stats(g, row, col, 17)[0]
        top /= 16; bottom /= 16
        val whiteMean = if (flipped) top else bottom
        val blackMean = if (flipped) bottom else top
        if (abs(whiteMean - blackMean) < 15) return false
        whiteBrighter = whiteMean > blackMean
        pieceThr = (whiteMean + blackMean) / 2
        val expected = mapFromFen()
        val observed = read(g, flipped)
        return diff(expected, observed) <= 2
    }

    private fun mapFromFen(): IntArray {
        val r = IntArray(64)
        for (idx in 0 until 64) {
            val rank = idx / 8
            r[idx] = when (rank) { 0, 1 -> 1; 6, 7 -> 2; else -> 0 }
        }
        return r
    }

    fun read(g: Mat, flipped: Boolean): IntArray {
        val res = IntArray(64)
        for (idx in 0 until 64) {
            val (row, col) = cellOf(idx, flipped)
            val c = (row + col) % 2
            val st = stats(g, row, col, 8)
            val occupied = st[1] > emptyStd[c] * 1.8 + 5 || abs(st[0] - emptyMean[c]) > 30
            if (!occupied) { res[idx] = 0; continue }
            val bright = stats(g, row, col, 17)[0] > pieceThr
            res[idx] = if (bright == whiteBrighter) 1 else 2
        }
        return res
    }

    fun diff(a: IntArray, b: IntArray): Int { var d = 0; for (i in 0 until 64) if (a[i] != b[i]) d++; return d }
}
