package com.example.chessvision

import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.MatOfDouble
import org.opencv.core.Rect
import org.opencv.imgproc.Imgproc
import kotlin.math.abs

/**
 * Распознавание цифровой доски со скриншота. При калибровке (начальная позиция)
 * вырезает образцы всех фигур этой темы, дальше узнаёт фигуры сопоставлением с образцами.
 */
class ScreenRecognizer {
    companion object { const val OCC = 15.0 }

    private val cell = SquareClassifier.CELL
    private val tpl = HashMap<String, MutableList<Mat>>()
    var flipped = false; private set
    var calibrated = false; private set
    private var thr = 128.0

    fun cellOf(idx: Int, fl: Boolean = flipped): Pair<Int, Int> {
        val file = idx % 8; val rank = idx / 8
        return if (fl) Pair(rank, 7 - file) else Pair(7 - rank, file)
    }

    private fun stats(g: Mat, row: Int, col: Int, pad: Int): DoubleArray {
        val roi = g.submat(Rect(col * cell + pad, row * cell + pad, cell - 2 * pad, cell - 2 * pad))
        val m = MatOfDouble(); val s = MatOfDouble()
        Core.meanStdDev(roi, m, s)
        val r = doubleArrayOf(m.get(0, 0)[0], s.get(0, 0)[0])
        roi.release(); m.release(); s.release()
        return r
    }

    fun calibrate(g: Mat): Boolean {
        var top = 0.0; var bottom = 0.0
        for (col in 0..7) {
            top += stats(g, 0, col, 17)[0] + stats(g, 1, col, 17)[0]
            bottom += stats(g, 6, col, 17)[0] + stats(g, 7, col, 17)[0]
        }
        if (abs(top - bottom) / 16 < 40) return false
        val fl = top > bottom   // белые фигуры светлее
        val w = if (fl) top else bottom
        val b = if (fl) bottom else top
        var bad = 0
        for (idx in 0 until 64) {
            val (r, c) = cellOf(idx, fl)
            val occ = stats(g, r, c, 14)[1] > OCC
            val should = idx / 8 <= 1 || idx / 8 >= 6
            if (occ != should) bad++
        }
        if (bad > 3) return false
        flipped = fl
        thr = (w + b) / 32
        tpl.clear()
        val back = "RNBQKBNR"
        for (idx in 0 until 64) {
            val rank = idx / 8; val file = idx % 8
            val key = when (rank) {
                0 -> "w" + back[file]
                1 -> "wP"
                6 -> "bP"
                7 -> "b" + back[file]
                else -> continue
            }
            val (r, c) = cellOf(idx, fl)
            tpl.getOrPut(key) { mutableListOf() }.add(g.submat(Rect(c * cell + 8, r * cell + 8, 34, 34)).clone())
        }
        calibrated = true
        return true
    }

    private fun typeOf(g: Mat, r: Int, c: Int, white: Boolean): Char {
        val reg = g.submat(Rect(c * cell + 3, r * cell + 3, 44, 44))
        var best = 'P'; var bs = -2.0
        for (t in "PNBRQK") {
            val list = tpl[(if (white) "w" else "b") + t] ?: continue
            for (m in list) {
                val res = Mat()
                Imgproc.matchTemplate(reg, m, res, Imgproc.TM_CCOEFF_NORMED)
                val s = Core.minMaxLoc(res).maxVal
                res.release()
                if (!s.isNaN() && s > bs) { bs = s; best = t }
            }
        }
        reg.release()
        return best
    }

    /** FEN: ходит сторона, фигуры которой снизу (то есть ваши). null, если позиция не распознана. */
    fun toFen(g: Mat): String? {
        val sq = CharArray(64) { ' ' }
        for (idx in 0 until 64) {
            val (r, c) = cellOf(idx)
            if (stats(g, r, c, 14)[1] <= OCC) continue
            val white = stats(g, r, c, 17)[0] > thr
            val t = typeOf(g, r, c, white)
            sq[idx] = if (white) t else t.lowercaseChar()
        }
        if (sq.count { it == 'K' } != 1 || sq.count { it == 'k' } != 1) return null
        for (i in 0..7) if (sq[i] == 'P' || sq[i] == 'p' || sq[56 + i] == 'P' || sq[56 + i] == 'p') return null
        val sb = StringBuilder()
        for (rank in 7 downTo 0) {
            var e = 0
            for (file in 0..7) {
                val ch = sq[rank * 8 + file]
                if (ch == ' ') e++ else { if (e > 0) { sb.append(e); e = 0 }; sb.append(ch) }
            }
            if (e > 0) sb.append(e)
            if (rank > 0) sb.append('/')
        }
        var cs = ""
        if (sq[4] == 'K') { if (sq[7] == 'R') cs += "K"; if (sq[0] == 'R') cs += "Q" }
        if (sq[60] == 'k') { if (sq[63] == 'r') cs += "k"; if (sq[56] == 'r') cs += "q" }
        if (cs.isEmpty()) cs = "-"
        return "$sb ${if (flipped) "b" else "w"} $cs - 0 1"
    }
}
