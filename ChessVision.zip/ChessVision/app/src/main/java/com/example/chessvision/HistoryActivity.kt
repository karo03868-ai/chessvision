package com.example.chessvision

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class HistoryActivity : AppCompatActivity() {
    private lateinit var list: ListView
    private lateinit var empty: TextView
    private var items: List<History.Item> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        list = findViewById(R.id.list)
        empty = findViewById(R.id.empty)
        list.setOnItemClickListener { _, _, pos, _ -> showMenu(items[pos]) }
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    private fun reload() {
        items = History.list(this)
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items.map { it.title })
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun showMenu(item: History.Item) {
        AlertDialog.Builder(this)
            .setTitle("Партия")
            .setItems(arrayOf<CharSequence>("Разобрать партию", "Поделиться PGN", "Удалить")) { _, which ->
                when (which) {
                    0 -> startActivity(Intent(this, ReviewActivity::class.java).putExtra("pgn", item.pgn))
                    1 -> share(item.pgn)
                    else -> { item.file.delete(); reload() }
                }
            }
            .show()
    }

    private fun share(pgn: String) {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, pgn)
        startActivity(Intent.createChooser(i, "Поделиться PGN"))
    }
}
