package com.example.chessvision

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.Square
import com.github.bhlangonijr.chesslib.move.Move

class TrainerActivity : AppCompatActivity() {
    private val board = Board()
    private lateinit var boardView: BoardView
    private lateinit var msg: TextView
    private lateinit var idea: TextView
    private lateinit var spinner: Spinner
    private var line: List<String> = emptyList()
    private var ply = 0
    private var userWhite = true
    private var selected = -1
    private var mistakes = 0
    private var hints = 0
    private var finished = true
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trainer)
        boardView = findViewById(R.id.board)
        msg = findViewById(R.id.msg)
        idea = findViewById(R.id.idea)
        spinner = findViewById(R.id.spinner)
        spinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            Openings.all.map { (if (it.userWhite) "Белые: " else "Чёрные: ") + it.name }
        )
        findViewById<Button>(R.id.btnStart).setOnClickListener { start() }
        findViewById<Button>(R.id.btnHint).setOnClickListener { hint() }
        boardView.onTap = { tap(it) }
        start()
    }

    private fun isUserTurn() = (board.sideToMove == Side.WHITE) == userWhite

    private fun start() {
        handler.removeCallbacksAndMessages(null)
        val o = Openings.all[spinner.selectedItemPosition]
        line = Openings.uciLine(o)
        userWhite = o.userWhite
        board.loadFromFen(SquareClassifier.START_FEN)
        ply = 0; selected = -1; mistakes = 0; hints = 0; finished = false
        boardView.flipped = !userWhite
        boardView.selected = -1
        boardView.lastFrom = -1; boardView.lastTo = -1
        boardView.setArrows(emptyList())
        boardView.setFen(board.fen)
        idea.text = "Идея: " + o.idea
        scheduleOpponent()
    }

    private fun scheduleOpponent() {
        if (finished) return
        if (ply >= line.size) { finish(); return }
        if (isUserTurn()) { msg.text = "Ваш ход"; return }
        msg.text = "Ход соперника…"
        handler.postDelayed({
            if (finished) return@postDelayed
            if (!playUci(line[ply])) { finish(); return@postDelayed }
            scheduleOpponent()
        }, 600)
    }

    private fun playMove(m: Move) {
        board.doMove(m)
        ply++
        boardView.lastFrom = San.idx(m.from)
        boardView.lastTo = San.idx(m.to)
        boardView.setArrows(emptyList())
        boardView.setFen(board.fen)
    }

    private fun playUci(u: String): Boolean {
        val m = board.legalMoves().firstOrNull { San.uci(it) == u } ?: return false
        playMove(m)
        return true
    }

    private fun tap(idx: Int) {
        if (finished || !isUserTurn()) return
        val userSide = if (userWhite) Side.WHITE else Side.BLACK
        val p = board.getPiece(Square.squareAt(idx))
        val mine = p != Piece.NONE && p.pieceSide == userSide
        if (selected < 0) {
            if (mine) { selected = idx; boardView.selected = idx }
            return
        }
        if (idx == selected) { selected = -1; boardView.selected = -1; return }
        if (mine) { selected = idx; boardView.selected = idx; return }
        val from = selected
        selected = -1; boardView.selected = -1
        val cand = board.legalMoves().filter { San.idx(it.from) == from && San.idx(it.to) == idx }
        if (cand.isEmpty()) { msg.text = "Так ходить нельзя"; return }
        val m = cand.firstOrNull { it.promotion != Piece.NONE && it.promotion.pieceType == PieceType.QUEEN } ?: cand[0]
        val expected = line[ply]
        if (San.uci(m).substring(0, 4) == expected.substring(0, 4)) {
            playMove(m)
            msg.text = "Верно ✓"
            scheduleOpponent()
        } else {
            mistakes++
            msg.text = "Не по теории. Попробуйте ещё раз"
        }
    }

    private fun hint() {
        if (finished || !isUserTurn() || ply >= line.size) return
        hints++
        val e = line[ply]
        boardView.setArrows(listOf(Triple(San.idx(e.substring(0, 2)), San.idx(e.substring(2, 4)), Color.argb(220, 0, 200, 0))))
        msg.text = "Подсказка: " + e.substring(0, 2) + " → " + e.substring(2, 4)
    }

    private fun finish() {
        finished = true
        msg.text = "Линия пройдена! Ошибок: $mistakes, подсказок: $hints"
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
