package com.example.chessvision

import com.github.bhlangonijr.chesslib.Board

data class Opening(val name: String, val userWhite: Boolean, val idea: String, val san: String)

object Openings {
    val all = listOf(
        Opening("Итальянская партия", true, "Быстро развить фигуры, нацелить слона на f7 и подготовить d3 и c3.",
            "e4 e5 Nf3 Nc6 Bc4 Bc5 c3 Nf6 d3 d6 O-O O-O"),
        Opening("Испанская партия", true, "Давить на коня c6, который защищает e5, и спокойно рокироваться.",
            "e4 e5 Nf3 Nc6 Bb5 a6 Ba4 Nf6 O-O Be7 Re1 b5 Bb3 d6 c3 O-O h3 Nb8 d4 Nbd7"),
        Opening("Ферзевый гамбит", true, "Занять центр пешками d4 и c4, развивать фигуры без спешки.",
            "d4 d5 c4 e6 Nc3 Nf6 Bg5 Be7 e3 O-O Nf3 h6 Bh4 b6"),
        Opening("Система Лондона", true, "Надёжная схема: слон f4, пешки d4, e3, c3, спокойное развитие.",
            "d4 d5 Bf4 Nf6 e3 c5 c3 Nc6 Nd2 e6 Ngf3 Bd6 Bg3 O-O Bd3"),
        Opening("Английское начало", true, "Борьба за центр с фланга: c4, затем g3 и слон g2.",
            "c4 e5 Nc3 Nf6 Nf3 Nc6 g3 d5 cxd5 Nxd5 Bg2 Nb6 O-O Be7"),
        Opening("Шотландская партия", true, "Открыть центр ходом d4 и получить активную игру.",
            "e4 e5 Nf3 Nc6 d4 exd4 Nxd4 Nf6 Nxc6 bxc6 e5 Qe7 Qe2 Nd5 c4 Ba6"),
        Opening("Сицилианская, Найдорф", false, "Играть на контратаку: пешка a6, затем e5 и активные фигуры.",
            "e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 a6 Be3 e5 Nb3 Be6 f3 Be7 Qd2 O-O O-O-O Nbd7"),
        Opening("Французская защита", false, "Прочная цепь пешек e6 и d5, контригра ходом c5.",
            "e4 e6 d4 d5 Nc3 Nf6 Bg5 Be7 e5 Nfd7 Bxe7 Qxe7 f4 O-O Nf3 c5"),
        Opening("Каро-Канн", false, "Выпустить слона c8 до того, как закроете его пешкой e6.",
            "e4 c6 d4 d5 Nc3 dxe4 Nxe4 Bf5 Ng3 Bg6 h4 h6 Nf3 Nd7 h5 Bh7 Bd3 Bxd3 Qxd3 e6"),
        Opening("Староиндийская защита", false, "Дать белым центр, а затем атаковать его ходами e5 и фианкеттированным слоном.",
            "d4 Nf6 c4 g6 Nc3 Bg7 e4 d6 Nf3 O-O Be2 e5 O-O Nc6 d5 Ne7"),
        Opening("Скандинавская защита", false, "Сразу размен в центре и быстрое развитие ферзя и фигур.",
            "e4 d5 exd5 Qxd5 Nc3 Qa5 d4 Nf6 Nf3 c6 Bc4 Bf5 Bd2 e6"),
        Opening("Славянская защита", false, "Держать центр пешкой d5 и c6, вывести слона наружу.",
            "d4 d5 c4 c6 Nf3 Nf6 Nc3 dxc4 a4 Bf5 e3 e6 Bxc4 Bb4 O-O Nbd7")
    )

    /** Превращает линию из SAN в список UCI-ходов. Если какой-то ход не прочитался, линия обрывается на нём. */
    fun uciLine(o: Opening): List<String> {
        val board = Board()
        val out = ArrayList<String>()
        for (tok in o.san.split(" ")) {
            val m = San.toMove(board, tok) ?: break
            out.add(San.uci(m))
            board.doMove(m)
        }
        return out
    }
}
