package com.example.chessvision

import android.content.ClipboardManager
import android.graphics.Color
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Side
import java.util.concurrent.Executors

class ReviewActivity : AppCompatActivity() {
    private lateinit var input: EditText
    private lateinit var summary: TextView
    private lateinit var boardView: BoardView
    private lateinit var adapter: ArrayAdapter<String>
    private val rows = ArrayList<String>()
    private var fens: List<String> = emptyList()
    private var played: List<String> = emptyList()
    private var bests: List<String?> = emptyList()
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var running = false
    private var engineStarted = false
    private lateinit var engine: StockfishEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_review)
        input = findViewById(R.id.input)
        summary = findViewById(R.id.summary)
        boardView = findViewById(R.id.board)
        boardView.setFen(SquareClassifier.START_FEN)
        val list = findViewById<ListView>(R.id.list)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, rows)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> show(pos) }
        engine = StockfishEngine(this)
        findViewById<Button>(R.id.btnPaste).setOnClickListener {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
            if (!t.isNullOrEmpty()) input.setText(t)
        }
        findViewById<Button>(R.id.btnRun).setOnClickListener {
            if (!running) {
                val text = input.text.toString()
                running = true
                rows.clear(); adapter.notifyDataSetChanged()
                summary.text = "Читаю партию…"
                worker.execute {
                    try { runReview(text) }
                    catch (e: Exception) { runOnUiThread { summary.text = "Ошибка: " + e.message } }
                    finally { running = false }
                }
            }
        }
        findViewById<Button>(R.id.btnFlip).setOnClickListener { boardView.flipped = !boardView.flipped }
    }

    private fun fmt(c: Int): String =
        if (Math.abs(c) >= 1000) (if (c > 0) "мат+" else "мат-") else String.format("%+.1f", c / 100.0)

    private fun arrow(u: String) = u.substring(0, 2) + "→" + u.substring(2, 4)

    private fun runReview(pgn: String) {
        val board = Board()
        val fenHdr = Regex("\\[FEN \"([^\"]+)\"\\]").find(pgn)?.groupValues?.get(1)
        if (fenHdr != null) board.loadFromFen(fenHdr)
        val sans = ArrayList<String>()
        val ucis = ArrayList<String>()
        val whiteMover = ArrayList<Boolean>()
        val fenList = ArrayList<String>()
        fenList.add(board.fen)
        var bad: String? = null
        for (t in San.tokens(pgn)) {
            val m = San.toMove(board, t)
            if (m == null) { bad = t; break }
            whiteMover.add(board.sideToMove == Side.WHITE)
            sans.add(t)
            ucis.add(San.uci(m))
            board.doMove(m)
            fenList.add(board.fen)
        }
        if (sans.isEmpty()) {
            runOnUiThread { summary.text = "Ходы не найдены. Вставьте PGN партии целиком." }
            return
        }
        if (!engineStarted) {
            engineStarted = engine.start()
            if (!engineStarted) { runOnUiThread { summary.text = "Нет движка Stockfish в приложении" }; return }
        }
        val n = fenList.size
        val ev = IntArray(n)
        val best = arrayOfNulls<String>(n)
        for (i in 0 until n) {
            val f = fenList[i]
            val a = engine.analyze(f, f.split(" ")[1] == "w", 300)
            if (a != null) { ev[i] = a.cpWhite.coerceIn(-1000, 1000); best[i] = a.best }
            runOnUiThread { summary.text = "Анализ: ${i + 1}/$n" }
        }
        val w = IntArray(3)
        val b = IntArray(3)
        val newRows = ArrayList<String>()
        var no = 1
        for (i in sans.indices) {
            val white = whiteMover[i]
            val loss = (if (white) ev[i] - ev[i + 1] else ev[i + 1] - ev[i]).coerceAtLeast(0)
            val isBest = ucis[i] == best[i]
            val label = when {
                isBest -> "★ лучший"
                loss <= 30 -> "хороший"
                loss <= 100 -> "неточность ?!"
                loss <= 250 -> "ошибка ?"
                else -> "грубая ошибка ??"
            }
            if (!isBest) {
                val k = when { loss <= 30 -> -1; loss <= 100 -> 0; loss <= 250 -> 1; else -> 2 }
                if (k >= 0) { if (white) w[k]++ else b[k]++ }
            }
            val num = if (white) "$no." else "$no..."
            val bi = best[i]
            var row = "$num ${sans[i]}   ${fmt(ev[i + 1])}   $label"
            if (!isBest && loss > 100 && bi != null) row += "\n    лучше: " + arrow(bi)
            newRows.add(row)
            if (!white) no++
        }
        val text = "Белые: грубых ${w[2]}, ошибок ${w[1]}, неточностей ${w[0]}\n" +
            "Чёрные: грубых ${b[2]}, ошибок ${b[1]}, неточностей ${b[0]}" +
            (if (bad != null) "\nНе удалось прочитать ход «$bad», разобрано до него" else "") +
            "\nНажмите на ход, чтобы увидеть позицию."
        runOnUiThread {
            fens = fenList; played = ucis; bests = best.toList()
            rows.addAll(newRows); adapter.notifyDataSetChanged()
            summary.text = text
            show(0)
        }
    }

    private fun show(pos: Int) {
        if (pos >= fens.size || pos >= played.size) return
        boardView.setFen(fens[pos])
        boardView.lastFrom = -1; boardView.lastTo = -1
        val pl = played[pos]
        val arrows = ArrayList<Triple<Int, Int, Int>>()
        val bi = bests[pos]
        if (bi != null && bi != pl) arrows.add(Triple(San.idx(bi.substring(0, 2)), San.idx(bi.substring(2, 4)), Color.argb(220, 0, 200, 0)))
        arrows.add(Triple(San.idx(pl.substring(0, 2)), San.idx(pl.substring(2, 4)), Color.argb(200, 220, 50, 50)))
        boardView.setArrows(arrows)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::engine.isInitialized) engine.stop()
        worker.shutdown()
    }
}
