package com.example.chessvision

import android.graphics.Color
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.PieceType
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.Square
import com.github.bhlangonijr.chesslib.move.Move
import java.util.concurrent.Executors

class PlayActivity : AppCompatActivity() {
    private class Level(val name: String, val skill: Int, val ms: Int)

    private val levels = listOf(
        Level("Новичок", 1, 150), Level("Любитель", 5, 300), Level("Клубный игрок", 10, 500),
        Level("Сильный", 15, 800), Level("Максимум", 20, 1000)
    )
    private val board = Board()
    private lateinit var boardView: BoardView
    private lateinit var msg: TextView
    private lateinit var spinner: Spinner
    private lateinit var engine: StockfishEngine
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var seq = 0
    private var userWhite = true
    private var selected = -1
    private var over = true
    private var plies = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_play)
        boardView = findViewById(R.id.board)
        msg = findViewById(R.id.msg)
        spinner = findViewById(R.id.spinner)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, levels.map { it.name })
        spinner.setSelection(1)
        engine = StockfishEngine(this)
        worker.execute {
            if (!engine.start()) runOnUiThread { msg.text = "Нет движка Stockfish в приложении" }
        }
        findViewById<Button>(R.id.btnWhite).setOnClickListener { newGame(true) }
        findViewById<Button>(R.id.btnBlack).setOnClickListener { newGame(false) }
        findViewById<Button>(R.id.btnUndo).setOnClickListener { undo() }
        findViewById<Button>(R.id.btnHint).setOnClickListener { hint() }
        boardView.onTap = { tap(it) }
        newGame(true)
    }

    private fun userTurn() = (board.sideToMove == Side.WHITE) == userWhite

    private fun arrow(u: String) = u.substring(0, 2) + "→" + u.substring(2, 4)

    private fun newGame(white: Boolean) {
        seq++
        val lv = levels[spinner.selectedItemPosition]
        worker.execute { engine.setSkill(lv.skill) }
        board.loadFromFen(SquareClassifier.START_FEN)
        userWhite = white; selected = -1; over = false; plies = 0
        boardView.flipped = !white
        boardView.selected = -1
        boardView.lastFrom = -1; boardView.lastTo = -1
        boardView.setArrows(emptyList())
        boardView.setFen(board.fen)
        if (white) msg.text = "Ваш ход" else engineMove()
    }

    private fun applyMove(m: Move) {
        board.doMove(m)
        plies++
        boardView.lastFrom = San.idx(m.from)
        boardView.lastTo = San.idx(m.to)
        boardView.setArrows(emptyList())
        boardView.setFen(board.fen)
    }

    private fun checkEnd(): Boolean {
        if (board.legalMoves().isEmpty()) {
            over = true
            msg.text = if (board.isKingAttacked) {
                if (userTurn()) "Мат. Вы проиграли" else "Мат! Вы выиграли!"
            } else "Пат — ничья"
            return true
        }
        return false
    }

    private fun engineMove() {
        val my = ++seq
        val fen = board.fen
        val wtm = board.sideToMove == Side.WHITE
        val lv = levels[spinner.selectedItemPosition]
        msg.text = "Соперник думает…"
        worker.execute {
            val a = engine.analyze(fen, wtm, lv.ms)
            runOnUiThread {
                if (my != seq || over) return@runOnUiThread
                val u = a?.best
                if (a == null) { msg.text = "Движок недоступен"; return@runOnUiThread }
                if (u == null) { checkEnd(); return@runOnUiThread }
                val m = board.legalMoves().firstOrNull { San.uci(it) == u }
                if (m == null) { msg.text = "Ошибка движка"; return@runOnUiThread }
                applyMove(m)
                if (!checkEnd()) msg.text = "Ваш ход. Соперник сыграл " + arrow(u)
            }
        }
    }

    private fun tap(idx: Int) {
        if (over || !userTurn()) return
        val userSide = if (userWhite) Side.WHITE else Side.BLACK
        val p = board.getPiece(Square.squareAt(idx))
        val mine = p != Piece.NONE && p.pieceSide == userSide
        if (selected < 0) {
            if (mine) { selected = idx; boardView.selected = idx }
            return
        }
        if (idx == selected) { selected = -1; boardView.selected = -1; return }
        if (mine) { selected = idx; boardView.selected = idx; return }
        val from = selected
        selected = -1; boardView.selected = -1
        val cand = board.legalMoves().filter { San.idx(it.from) == from && San.idx(it.to) == idx }
        if (cand.isEmpty()) { msg.text = "Так ходить нельзя"; return }
        val m = cand.firstOrNull { it.promotion != Piece.NONE && it.promotion.pieceType == PieceType.QUEEN } ?: cand[0]
        applyMove(m)
        if (!checkEnd()) engineMove()
    }

    private fun undo() {
        seq++
        over = false
        selected = -1; boardView.selected = -1
        val n = if (userTurn()) 2 else 1
        var k = 0
        while (k < n && plies > 0) { board.undoMove(); plies--; k++ }
        boardView.lastFrom = -1; boardView.lastTo = -1
        boardView.setArrows(emptyList())
        boardView.setFen(board.fen)
        if (userTurn()) msg.text = "Ваш ход" else engineMove()
    }

    private fun hint() {
        if (over || !userTurn()) return
        val fen = board.fen
        val wtm = board.sideToMove == Side.WHITE
        msg.text = "Ищу подсказку…"
        worker.execute {
            val a = engine.analyze(fen, wtm, 600)
            runOnUiThread {
                val u = a?.best
                if (u != null && board.fen == fen) {
                    boardView.setArrows(listOf(Triple(San.idx(u.substring(0, 2)), San.idx(u.substring(2, 4)), Color.argb(220, 0, 200, 0))))
                    msg.text = "Подсказка: " + arrow(u)
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        seq++
        if (::engine.isInitialized) engine.stop()
        worker.shutdown()
    }
}
