package com.example.homefit

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class LibraryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_library)
        val items = Data.exercises.values.sortedBy { it.name }
        val list = findViewById<ListView>(R.id.list)
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items.map { it.name + "\n" + it.muscles })
        list.setOnItemClickListener { _, _, pos, _ ->
            val e = items[pos]
            AlertDialog.Builder(this)
                .setTitle(e.name)
                .setMessage(e.muscles + "\n\n" + e.howTo + "\n\nПроще: " + e.easier + "\nСложнее: " + e.harder)
                .setPositiveButton("Понятно", null)
                .show()
        }
    }
}
