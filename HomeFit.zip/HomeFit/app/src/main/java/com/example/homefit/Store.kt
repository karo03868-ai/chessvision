package com.example.homefit

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("homefit", Context.MODE_PRIVATE)

    class Entry(val date: Long, val workout: Int, val level: Int, val sets: Int)

    var level: Int
        get() = sp.getInt("level", 0)
        set(v) { sp.edit().putInt("level", v).apply() }

    var next: Int
        get() = sp.getInt("next", 0)
        set(v) { sp.edit().putInt("next", v).apply() }

    fun lastReps(ex: String): List<Int> =
        (sp.getString("last_$ex", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }

    fun setLastReps(ex: String, list: List<Int>) {
        sp.edit().putString("last_$ex", list.joinToString(",")).apply()
    }

    fun addEntry(e: Entry) {
        val arr = JSONArray(sp.getString("hist", "[]"))
        arr.put(JSONObject().put("d", e.date).put("w", e.workout).put("l", e.level).put("s", e.sets))
        sp.edit().putString("hist", arr.toString()).apply()
    }

    fun entries(): List<Entry> {
        val arr = JSONArray(sp.getString("hist", "[]"))
        val out = ArrayList<Entry>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(Entry(o.getLong("d"), o.getInt("w"), o.getInt("l"), o.getInt("s")))
        }
        return out
    }

    fun addWeight(kg: Double) {
        val arr = JSONArray(sp.getString("wt", "[]"))
        arr.put(JSONObject().put("d", System.currentTimeMillis()).put("kg", kg))
        sp.edit().putString("wt", arr.toString()).apply()
    }

    fun weights(): List<Pair<Long, Double>> {
        val arr = JSONArray(sp.getString("wt", "[]"))
        val out = ArrayList<Pair<Long, Double>>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(Pair(o.getLong("d"), o.getDouble("kg")))
        }
        return out
    }
}
