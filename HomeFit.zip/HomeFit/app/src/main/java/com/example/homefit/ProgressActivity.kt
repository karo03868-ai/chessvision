package com.example.homefit

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ProgressActivity : AppCompatActivity() {
    private lateinit var store: Store
    private lateinit var stats: TextView
    private lateinit var chart: WeightChartView
    private lateinit var list: ListView
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_progress)
        store = Store(this)
        stats = findViewById(R.id.stats)
        chart = findViewById(R.id.chart)
        list = findViewById(R.id.list)
        input = findViewById(R.id.weightInput)
        findViewById<Button>(R.id.btnSaveWeight).setOnClickListener {
            val v = input.text.toString().replace(',', '.').toDoubleOrNull()
            if (v == null || v < 20 || v > 300) {
                Toast.makeText(this, "Введите вес от 20 до 300 кг", Toast.LENGTH_SHORT).show()
            } else {
                store.addWeight(v)
                input.setText("")
                refresh()
            }
        }
        refresh()
    }

    private fun refresh() {
        val entries = store.entries()
        val now = System.currentTimeMillis()
        val week = entries.count { now - it.date < 7L * 24 * 3600 * 1000 }
        stats.text = "Тренировок: ${entries.size}, за 7 дней: $week"
        chart.setData(store.weights().map { it.second })
        val fmt = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
        val rows = entries.reversed().map {
            fmt.format(Date(it.date)) + " — " + Data.workouts[it.workout].title +
                " (" + Data.levels[it.level] + "), подходов: " + it.sets
        }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, rows)
    }
}
