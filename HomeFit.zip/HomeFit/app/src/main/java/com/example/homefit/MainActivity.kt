package com.example.homefit

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var store: Store
    private lateinit var nextText: TextView
    private lateinit var levelHint: TextView
    private lateinit var statsText: TextView
    private lateinit var levelSpinner: Spinner
    private var chosen = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = Store(this)
        nextText = findViewById(R.id.nextText)
        levelHint = findViewById(R.id.levelHint)
        statsText = findViewById(R.id.statsText)
        levelSpinner = findViewById(R.id.levelSpinner)
        levelSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Data.levels)
        levelSpinner.setSelection(store.level)
        levelSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                store.level = pos
                refresh()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        findViewById<Button>(R.id.btnStart).setOnClickListener {
            startActivity(
                Intent(this, WorkoutActivity::class.java).putExtra("w", chosen).putExtra("level", store.level)
            )
        }
        findViewById<Button>(R.id.btnChoose).setOnClickListener {
            val names = Data.workouts.map { it.title }.toTypedArray<CharSequence>()
            AlertDialog.Builder(this)
                .setTitle("Выберите тренировку")
                .setItems(names) { _, which -> chosen = which; refresh() }
                .show()
        }
        findViewById<Button>(R.id.btnLibrary).setOnClickListener { startActivity(Intent(this, LibraryActivity::class.java)) }
        findViewById<Button>(R.id.btnProgress).setOnClickListener { startActivity(Intent(this, ProgressActivity::class.java)) }
    }

    override fun onResume() {
        super.onResume()
        chosen = store.next
        refresh()
    }

    private fun refresh() {
        val w = Data.workouts[chosen]
        levelHint.text = Data.levelHints[store.level]
        nextText.text = "Следующая: " + w.title + "\n" + w.focus + ", около " + w.minutes + " минут"
        val now = System.currentTimeMillis()
        val week = store.entries().count { now - it.date < 7L * 24 * 3600 * 1000 }
        statsText.text = "Тренировок за 7 дней: $week. Всего: ${store.entries().size}. Лучше всего 3–4 раза в неделю с днями отдыха."
    }
}
