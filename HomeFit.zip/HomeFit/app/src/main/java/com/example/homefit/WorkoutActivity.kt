package com.example.homefit

import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class WorkoutActivity : AppCompatActivity() {
    private lateinit var store: Store
    private lateinit var title: TextView
    private lateinit var sub: TextView
    private lateinit var target: TextView
    private lateinit var last: TextView
    private lateinit var timerText: TextView
    private lateinit var repsRow: LinearLayout
    private lateinit var repsText: TextView
    private lateinit var desc: TextView
    private lateinit var btnMain: Button
    private var slots: List<Slot> = emptyList()
    private var workoutId = 0
    private var level = 0
    private var step = 0
    private var setNo = 0
    private var reps = 0
    private var resting = false
    private var running = false
    private var elapsed = 0
    private var totalSets = 0
    private var restTimer: CountDownTimer? = null
    private var restThen: (() -> Unit)? = null
    private val results = HashMap<String, ArrayList<Int>>()
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_workout)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        store = Store(this)
        workoutId = intent.getIntExtra("w", 0)
        level = intent.getIntExtra("level", 0)
        slots = Data.program(workoutId, level)
        title = findViewById(R.id.title)
        sub = findViewById(R.id.sub)
        target = findViewById(R.id.target)
        last = findViewById(R.id.last)
        timerText = findViewById(R.id.timerText)
        repsRow = findViewById(R.id.repsRow)
        repsText = findViewById(R.id.repsText)
        desc = findViewById(R.id.desc)
        btnMain = findViewById(R.id.btnMain)
        findViewById<Button>(R.id.btnMinus).setOnClickListener { if (reps > 0) { reps--; repsText.text = reps.toString() } }
        findViewById<Button>(R.id.btnPlus).setOnClickListener { reps++; repsText.text = reps.toString() }
        btnMain.setOnClickListener { onMain() }
        findViewById<Button>(R.id.btnHow).setOnClickListener {
            desc.visibility = if (desc.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        findViewById<Button>(R.id.btnSkip).setOnClickListener { skipExercise() }
        show()
    }

    private fun vibrate() {
        try {
            val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(400, VibrationEffect.DEFAULT_AMPLITUDE))
            else @Suppress("DEPRECATION") v.vibrate(400)
        } catch (e: Exception) { }
    }

    private fun show() {
        val s = slots[step]
        val ex = Data.exercises.getValue(s.exId)
        resting = false
        running = false
        title.text = ex.name
        sub.text = "Упражнение ${step + 1}/${slots.size}, подход ${setNo + 1}/${s.sets}" + (if (s.warm) " (разминка)" else "")
        val unit = if (ex.timed) "сек" else "повторов"
        target.text = if (s.lo == s.hi) "Цель: ${s.lo} $unit" else "Цель: ${s.lo}–${s.hi} $unit"
        desc.text = ex.muscles + "\n\n" + ex.howTo + "\n\nПроще: " + ex.easier + "\nСложнее: " + ex.harder
        val prev = if (s.warm) emptyList() else store.lastReps(s.exId)
        last.text = if (prev.isEmpty()) "" else "В прошлый раз: " + prev.joinToString(", ")
        if (ex.timed) {
            repsRow.visibility = View.GONE
            elapsed = 0
            timerText.text = "0 сек"
            btnMain.text = "Старт"
        } else {
            repsRow.visibility = View.VISIBLE
            reps = prev.getOrNull(setNo) ?: s.lo
            repsText.text = reps.toString()
            timerText.text = ""
            btnMain.text = "Подход выполнен"
        }
    }

    private fun onMain() {
        if (resting) { skipRest(); return }
        val s = slots[step]
        val ex = Data.exercises.getValue(s.exId)
        if (ex.timed) {
            if (!running) {
                running = true
                elapsed = 0
                btnMain.text = "Стоп"
                tick(s.hi)
            } else {
                running = false
                handler.removeCallbacksAndMessages(null)
                doneSet(elapsed)
            }
        } else doneSet(reps)
    }

    private fun tick(goal: Int) {
        handler.postDelayed({
            if (running) {
                elapsed++
                timerText.text = "$elapsed сек"
                if (elapsed == goal) vibrate()
                tick(goal)
            }
        }, 1000)
    }

    private fun doneSet(value: Int) {
        val s = slots[step]
        if (!s.warm) {
            results.getOrPut(s.exId) { ArrayList() }.add(value)
            totalSets++
        }
        val lastSet = setNo + 1 >= s.sets
        val lastStep = step + 1 >= slots.size
        if (lastSet && lastStep) { finishWorkout(); return }
        val nextName = Data.exercises.getValue(if (lastSet) slots[step + 1].exId else s.exId).name
        startRest(s.rest, nextName) {
            if (lastSet) { step++; setNo = 0 } else setNo++
            show()
        }
    }

    private fun startRest(sec: Int, nextName: String, then: () -> Unit) {
        resting = true
        running = false
        restThen = then
        repsRow.visibility = View.GONE
        last.text = ""
        sub.text = "Далее: $nextName"
        btnMain.text = "Пропустить отдых"
        restTimer = object : CountDownTimer(sec * 1000L, 1000) {
            override fun onTick(ms: Long) { timerText.text = "Отдых: ${ms / 1000 + 1} сек" }
            override fun onFinish() { vibrate(); finishRest() }
        }.start()
    }

    private fun finishRest() {
        if (!resting) return
        resting = false
        val t = restThen
        restThen = null
        t?.invoke()
    }

    private fun skipRest() {
        restTimer?.cancel()
        finishRest()
    }

    private fun skipExercise() {
        restTimer?.cancel()
        handler.removeCallbacksAndMessages(null)
        resting = false
        running = false
        if (step + 1 >= slots.size) finishWorkout() else { step++; setNo = 0; show() }
    }

    private fun finishWorkout() {
        handler.removeCallbacksAndMessages(null)
        restTimer?.cancel()
        val sb = StringBuilder("Подходов выполнено: $totalSets\n\n")
        for ((exId, list) in results) {
            val slot = slots.first { it.exId == exId && !it.warm }
            val ex = Data.exercises.getValue(exId)
            store.setLastReps(exId, list)
            val ok = list.size >= slot.sets && list.all { it >= slot.hi }
            if (ok) sb.append("• ").append(ex.name).append(": пора усложнить. ").append(ex.harder).append("\n")
            else sb.append("• ").append(ex.name).append(": ").append(list.joinToString(", ")).append("\n")
        }
        if (totalSets > 0) {
            store.addEntry(Store.Entry(System.currentTimeMillis(), workoutId, level, totalSets))
            store.next = (workoutId + 1) % Data.workouts.size
        }
        sb.append("\nРастяните мышцы и выпейте воды. Следующая тренировка через день отдыха.")
        AlertDialog.Builder(this)
            .setTitle("Тренировка завершена")
            .setMessage(sb.toString())
            .setCancelable(false)
            .setPositiveButton("Готово") { _, _ -> finish() }
            .show()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        AlertDialog.Builder(this)
            .setMessage("Выйти из тренировки? Результаты не сохранятся.")
            .setPositiveButton("Выйти") { _, _ -> finish() }
            .setNegativeButton("Продолжить", null)
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        restTimer?.cancel()
    }
}
