package com.example.homefit

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

class WeightChartView(c: Context, a: AttributeSet?) : View(c, a) {
    private var pts: List<Double> = emptyList()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(76, 175, 80); strokeWidth = 5f; style = Paint.Style.STROKE }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(76, 175, 80); style = Paint.Style.FILL }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GRAY; textSize = 30f }

    fun setData(v: List<Double>) { pts = v; invalidate() }

    override fun onDraw(cv: Canvas) {
        if (pts.size < 2) {
            cv.drawText("Запишите вес хотя бы два раза", 16f, height / 2f, text)
            return
        }
        val mn = pts.minOrNull() ?: 0.0
        val mx = pts.maxOrNull() ?: 0.0
        val range = maxOf(mx - mn, 0.5)
        val pad = 40f
        val w = width - 2 * pad
        val h = height - 2 * pad
        var px = 0f
        var py = 0f
        for (i in pts.indices) {
            val x = pad + i * w / (pts.size - 1)
            val y = (height - pad - ((pts[i] - mn) / range * h)).toFloat()
            if (i > 0) cv.drawLine(px, py, x, y, line)
            cv.drawCircle(x, y, 8f, dot)
            px = x; py = y
        }
        cv.drawText(String.format("%.1f", mx), 4f, pad - 8f, text)
        cv.drawText(String.format("%.1f", mn), 4f, height - 4f, text)
    }
}
